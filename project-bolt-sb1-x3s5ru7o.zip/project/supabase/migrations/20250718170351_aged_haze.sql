/*
  # Add stock update function

  1. New Function
    - `update_product_stock` - Safely decreases product stock quantity
    - Prevents negative stock values
    - Returns updated stock quantity

  2. Security
    - Function is accessible to authenticated users
    - Includes validation to prevent overselling
*/

-- Function to update product stock safely
CREATE OR REPLACE FUNCTION update_product_stock(
  product_id uuid,
  quantity_sold integer
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_stock integer;
  new_stock integer;
BEGIN
  -- Get current stock
  SELECT stock_quantity INTO current_stock
  FROM products
  WHERE id = product_id;
  
  -- Check if product exists
  IF current_stock IS NULL THEN
    RAISE EXCEPTION 'Product not found';
  END IF;
  
  -- Calculate new stock
  new_stock := current_stock - quantity_sold;
  
  -- Prevent negative stock
  IF new_stock < 0 THEN
    new_stock := 0;
  END IF;
  
  -- Update stock
  UPDATE products
  SET stock_quantity = new_stock,
      updated_at = now()
  WHERE id = product_id;
  
  RETURN new_stock;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_product_stock(uuid, integer) TO authenticated;