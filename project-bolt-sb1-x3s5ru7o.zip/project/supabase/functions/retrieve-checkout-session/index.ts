/*
  # Retrieve Checkout Session Edge Function

  1. Purpose
    - Retrieve Stripe checkout session details
    - Used for order confirmation pages
    - Provides session data for order processing

  2. Security
    - Uses Stripe secret key securely on backend
    - Validates session ownership
    - Handles CORS for frontend requests
*/

import Stripe from 'npm:stripe@14.12.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    const { session_id } = await req.json();

    if (!session_id) {
      throw new Error('Session ID is required');
    }

    const session = await stripe.checkout.sessions.retrieve(session_id, {
      expand: ['line_items', 'customer', 'payment_intent'],
    });

    // Only return essential data for security
    const sessionData = {
      id: session.id,
      amount_total: session.amount_total,
      currency: session.currency,
      customer_details: session.customer_details,
      shipping_details: session.shipping_details,
      payment_status: session.payment_status,
      status: session.status,
      metadata: session.metadata,
      created: session.created,
      expires_at: session.expires_at,
    };

    return new Response(
      JSON.stringify(sessionData),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error retrieving checkout session:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});