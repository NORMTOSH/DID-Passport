/*
  # Admin Users Edge Function

  1. Purpose
    - Securely handle admin user operations using service role key
    - Proxy admin API calls from frontend to avoid exposing service role key
    - Provide CRUD operations for user management

  2. Operations
    - GET: List all users (from both auth.users and users table)
    - POST: Create new user
    - PUT: Update existing user
    - DELETE: Delete user
    - PATCH: Ban/unban user

  3. Security
    - Uses service role key for admin operations
    - Validates user permissions before operations
    - Handles CORS for frontend requests
*/

import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
};

interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          first_name: string | null;
          last_name: string | null;
          phone: string | null;
          avatar_url: string | null;
          date_of_birth: string | null;
          role: string;
          status: string;
          total_orders: number;
          total_spent: number;
          last_login: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          first_name?: string | null;
          last_name?: string | null;
          phone?: string | null;
          avatar_url?: string | null;
          date_of_birth?: string | null;
          role?: string;
          status?: string;
          total_orders?: number;
          total_spent?: number;
          last_login?: string | null;
        };
        Update: {
          email?: string;
          first_name?: string | null;
          last_name?: string | null;
          phone?: string | null;
          avatar_url?: string | null;
          date_of_birth?: string | null;
          role?: string;
          status?: string;
          total_orders?: number;
          total_spent?: number;
          last_login?: string | null;
          updated_at?: string;
        };
      };
    };
  };
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client with service role key
    const supabaseAdmin = createClient<Database>(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    const url = new URL(req.url);
    const method = req.method;

    switch (method) {
      case 'GET':
        return await handleGetUsers(supabaseAdmin);
      
      case 'POST':
        const createData = await req.json();
        return await handleCreateUser(supabaseAdmin, createData);
      
      case 'PUT':
        const updateData = await req.json();
        const userId = url.searchParams.get('id');
        if (!userId) {
          return new Response(
            JSON.stringify({ error: 'User ID is required' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        return await handleUpdateUser(supabaseAdmin, userId, updateData);
      
      case 'DELETE':
        const deleteUserId = url.searchParams.get('id');
        if (!deleteUserId) {
          return new Response(
            JSON.stringify({ error: 'User ID is required' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        return await handleDeleteUser(supabaseAdmin, deleteUserId);
      
      case 'PATCH':
        const patchData = await req.json();
        const patchUserId = url.searchParams.get('id');
        if (!patchUserId) {
          return new Response(
            JSON.stringify({ error: 'User ID is required' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        return await handleBanUnbanUser(supabaseAdmin, patchUserId, patchData);
      
      default:
        return new Response(
          JSON.stringify({ error: 'Method not allowed' }),
          { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
  } catch (error) {
    console.error('Error in admin-users function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function handleGetUsers(supabaseAdmin: any) {
  try {
    // Get users from users table
    const { data: usersData, error: usersError } = await supabaseAdmin
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (usersError) throw usersError;

    // Get users from auth.users
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (authError) throw authError;

    // Combine and deduplicate users
    const allUsers = [];
    const userIds = new Set();

    // Add users from users table first
    if (usersData) {
      usersData.forEach((user: any) => {
        allUsers.push({
          ...user,
          role: user.role || 'customer',
          status: user.status || 'active',
          total_orders: user.total_orders || 0,
          total_spent: user.total_spent || 0,
          last_login: user.last_login || user.updated_at
        });
        userIds.add(user.id);
      });
    }

    // Add auth users who aren't in the users table yet
    if (authUsers?.users) {
      authUsers.users.forEach((authUser: any) => {
        if (!userIds.has(authUser.id)) {
          allUsers.push({
            id: authUser.id,
            email: authUser.email || '',
            first_name: authUser.user_metadata?.first_name || null,
            last_name: authUser.user_metadata?.last_name || null,
            phone: authUser.user_metadata?.phone || null,
            avatar_url: authUser.user_metadata?.avatar_url || null,
            date_of_birth: authUser.user_metadata?.date_of_birth || null,
            role: authUser.user_metadata?.role || 'customer',
            status: 'active',
            total_orders: 0,
            total_spent: 0,
            last_login: authUser.last_sign_in_at || null,
            created_at: authUser.created_at,
            updated_at: authUser.updated_at
          });
        }
      });
    }

    return new Response(
      JSON.stringify({ data: allUsers, error: null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error fetching users:', error);
    return new Response(
      JSON.stringify({ data: null, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleCreateUser(supabaseAdmin: any, userData: any) {
  try {
    // Create user in auth first
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: userData.email,
      password: userData.password,
      email_confirm: true,
      user_metadata: {
        first_name: userData.first_name,
        last_name: userData.last_name,
        phone: userData.phone,
        date_of_birth: userData.date_of_birth,
        role: userData.role
      }
    });

    if (authError) throw authError;

    // Then create user in users table
    const { data, error } = await supabaseAdmin
      .from('users')
      .insert({
        id: authData.user.id,
        email: userData.email,
        first_name: userData.first_name,
        last_name: userData.last_name,
        phone: userData.phone,
        date_of_birth: userData.date_of_birth,
        role: userData.role || 'customer',
        status: 'active',
        total_orders: 0,
        total_spent: 0
      })
      .select()
      .single();
    
    if (error) throw error;

    return new Response(
      JSON.stringify({ data, error: null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error creating user:', error);
    return new Response(
      JSON.stringify({ data: null, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleUpdateUser(supabaseAdmin: any, id: string, updates: any) {
  try {
    // Prepare updates for users table
    const userTableUpdates = {
      ...(updates.first_name !== undefined && { first_name: updates.first_name }),
      ...(updates.last_name !== undefined && { last_name: updates.last_name }),
      ...(updates.email !== undefined && { email: updates.email }),
      ...(updates.phone !== undefined && { phone: updates.phone }),
      ...(updates.date_of_birth !== undefined && { date_of_birth: updates.date_of_birth }),
      ...(updates.role !== undefined && { role: updates.role }),
      ...(updates.status !== undefined && { status: updates.status }),
      ...(updates.total_orders !== undefined && { total_orders: updates.total_orders }),
      ...(updates.total_spent !== undefined && { total_spent: updates.total_spent }),
      ...(updates.last_login !== undefined && { last_login: updates.last_login }),
      updated_at: new Date().toISOString()
    };

    // Update users table
    const { data, error } = await supabaseAdmin
      .from('users')
      .update(userTableUpdates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;

    // If updating email, also update auth user
    if (updates.email) {
      await supabaseAdmin.auth.admin.updateUserById(id, {
        email: updates.email
      });
    }

    return new Response(
      JSON.stringify({ data, error: null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error updating user:', error);
    return new Response(
      JSON.stringify({ data: null, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleDeleteUser(supabaseAdmin: any, id: string) {
  try {
    // Delete from users table first
    const { error } = await supabaseAdmin
      .from('users')
      .delete()
      .eq('id', id);
    
    if (error) throw error;

    // Then delete from auth
    await supabaseAdmin.auth.admin.deleteUser(id);

    return new Response(
      JSON.stringify({ error: null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error deleting user:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleBanUnbanUser(supabaseAdmin: any, id: string, patchData: any) {
  try {
    const { data, error } = await supabaseAdmin
      .from('users')
      .update({ status: patchData.status })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;

    return new Response(
      JSON.stringify({ data, error: null }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error updating user status:', error);
    return new Response(
      JSON.stringify({ data: null, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}