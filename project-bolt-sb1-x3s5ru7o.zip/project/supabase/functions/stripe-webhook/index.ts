/*
  # Stripe Webhook Edge Function

  1. Purpose
    - Handle Stripe webhook events securely
    - Process successful payments and create orders
    - Update order status based on payment events

  2. Events Handled
    - checkout.session.completed: Create order and order items
    - payment_intent.payment_failed: Update transaction status
    - invoice.payment_succeeded: Handle subscription payments (future)

  3. Security
    - Validates webhook signature
    - Uses service role key for database operations
    - Handles CORS for webhook requests
*/

import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.12.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2023-10-16',
});

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.text();
    const signature = req.headers.get('stripe-signature');
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

    if (!signature || !webhookSecret) {
      throw new Error('Missing signature or webhook secret');
    }

    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    console.log(`Processing webhook event: ${event.type}`);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutSessionCompleted(session);
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await handlePaymentFailed(paymentIntent);
        break;
      }

      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await handlePaymentSucceeded(paymentIntent);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(
      JSON.stringify({ received: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});

async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session) {
  try {
    console.log('Processing completed checkout session:', session.id);

    const cartItems = JSON.parse(session.metadata?.cart_items || '[]');
    const subtotal = parseFloat(session.metadata?.subtotal || '0');
    const shippingCost = parseFloat(session.metadata?.shipping_cost || '0');
    const taxAmount = session.total_details?.amount_tax ? session.total_details.amount_tax / 100 : 0;
    const totalAmount = session.amount_total ? session.amount_total / 100 : 0;
    const userId = session.metadata?.user_id || session.client_reference_id;

    // Generate order number
    const orderNumber = `ORD-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        user_id: userId || null,
        order_number: orderNumber,
        status: 'confirmed',
        payment_status: 'paid',
        fulfillment_status: 'unfulfilled',
        subtotal,
        tax_amount: taxAmount,
        shipping_amount: shippingCost,
        discount_amount: 0,
        total_amount: totalAmount,
        currency: session.currency?.toUpperCase() || 'USD',
        shipping_address: session.shipping_details ? {
          name: session.shipping_details.name,
          address: session.shipping_details.address,
        } : null,
        billing_address: session.customer_details ? {
          name: session.customer_details.name,
          email: session.customer_details.email,
          address: session.customer_details.address,
        } : null,
        notes: `Stripe Session: ${session.id}`,
      })
      .select()
      .single();

    if (orderError) {
      console.error('Error creating order:', orderError);
      throw orderError;
    }

    console.log('Order created:', order.id);

    // Create order items
    for (const item of cartItems) {
      const { error: itemError } = await supabase
        .from('order_items')
        .insert({
          order_id: order.id,
          product_id: item.product_id,
          product_name: item.product_name || 'Unknown Product',
          product_sku: item.product_sku || 'N/A',
          quantity: item.quantity,
          unit_price: item.price,
          total_price: item.price * item.quantity,
        });

      if (itemError) {
        console.error('Error creating order item:', itemError);
      }

      // Update product stock
      const { error: stockError } = await supabase.rpc('update_product_stock', {
        product_id: item.product_id,
        quantity_sold: item.quantity
      });

      if (stockError) {
        console.error('Error updating stock:', stockError);
      }
    }

    // Create payment transaction record
    const { error: transactionError } = await supabase
      .from('payment_transactions')
      .insert({
        order_id: order.id,
        user_id: userId || null,
        transaction_id: session.payment_intent as string,
        payment_method: 'credit_card',
        payment_provider: 'stripe',
        amount: totalAmount,
        currency: session.currency?.toUpperCase() || 'USD',
        status: 'succeeded',
        gateway_response: session,
        metadata: {
          session_id: session.id,
          customer_email: session.customer_details?.email,
        },
        processed_at: new Date().toISOString(),
      });

    if (transactionError) {
      console.error('Error creating transaction:', transactionError);
    }

    // Clear user's cart if user_id exists
    if (userId) {
      const { error: cartError } = await supabase
        .from('cart_items')
        .delete()
        .eq('user_id', userId);

      if (cartError) {
        console.error('Error clearing cart:', cartError);
      }
    }

    console.log('Checkout session processing completed successfully');
  } catch (error) {
    console.error('Error processing checkout session:', error);
    throw error;
  }
}

async function handlePaymentFailed(paymentIntent: Stripe.PaymentIntent) {
  try {
    console.log('Processing failed payment:', paymentIntent.id);

    // Update payment transaction status
    const { error } = await supabase
      .from('payment_transactions')
      .update({ 
        status: 'failed',
        gateway_response: paymentIntent,
        processed_at: new Date().toISOString(),
      })
      .eq('transaction_id', paymentIntent.id);

    if (error) {
      console.error('Error updating failed payment:', error);
    }
  } catch (error) {
    console.error('Error handling payment failure:', error);
  }
}

async function handlePaymentSucceeded(paymentIntent: Stripe.PaymentIntent) {
  try {
    console.log('Processing successful payment:', paymentIntent.id);

    // Update payment transaction status
    const { error } = await supabase
      .from('payment_transactions')
      .update({ 
        status: 'succeeded',
        gateway_response: paymentIntent,
        processed_at: new Date().toISOString(),
      })
      .eq('transaction_id', paymentIntent.id);

    if (error) {
      console.error('Error updating successful payment:', error);
    }
  } catch (error) {
    console.error('Error handling payment success:', error);
  }
}