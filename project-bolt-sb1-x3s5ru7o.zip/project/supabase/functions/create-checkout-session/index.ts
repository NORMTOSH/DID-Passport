/*
  # Create Checkout Session Edge Function

  1. Purpose
    - Create Stripe checkout sessions for cart items
    - Handle shipping calculations and tax
    - Store order metadata for webhook processing

  2. Security
    - Uses Stripe secret key securely on backend
    - Validates cart items and pricing
    - Handles CORS for frontend requests
*/

import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@14.12.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { items, customer_email, success_url, cancel_url, user_id } = await req.json();

    if (!items || items.length === 0) {
      throw new Error('No items provided');
    }

    // Validate products exist and get current prices
    const productIds = items.map((item: any) => item.product.id);
    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('id, name, price, stock_quantity, is_active')
      .in('id', productIds);

    if (productsError) throw productsError;

    // Transform cart items to Stripe line items with validation
    const lineItems = [];
    let subtotal = 0;

    for (const item of items) {
      const product = products?.find(p => p.id === item.product.id);
      if (!product) {
        throw new Error(`Product ${item.product.id} not found`);
      }
      if (!product.is_active) {
        throw new Error(`Product ${product.name} is no longer available`);
      }
      if (product.stock_quantity < item.quantity) {
        throw new Error(`Insufficient stock for ${product.name}`);
      }

      const lineItem = {
        price_data: {
          currency: 'usd',
          product_data: {
            name: product.name,
            images: item.product.image ? [item.product.image] : [],
            metadata: {
              product_id: product.id,
              category: item.product.category || '',
              brand: item.product.brand || '',
            },
          },
          unit_amount: Math.round(product.price * 100), // Use current price from database
        },
        quantity: item.quantity,
      };

      // Only include description if it's not empty
      if (item.product.description && item.product.description.trim() !== '') {
        lineItem.price_data.product_data.description = item.product.description;
      }

      lineItems.push(lineItem);
      subtotal += product.price * item.quantity;
    }

    // Calculate shipping
    const freeShippingThreshold = 50;
    const shippingCost = subtotal >= freeShippingThreshold ? 0 : 9.99;

    // Add shipping as a line item if applicable
    if (shippingCost > 0) {
      lineItems.push({
        price_data: {
          currency: 'usd',
          product_data: {
            name: 'Standard Shipping',
            description: 'Standard shipping (5-7 business days)',
          },
          unit_amount: Math.round(shippingCost * 100),
        },
        quantity: 1,
      });
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: `${success_url}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url,
      customer_email,
      client_reference_id: user_id || null,
      shipping_address_collection: {
        allowed_countries: ['US', 'CA', 'GB', 'AU', 'DE', 'FR', 'IT', 'ES', 'NL', 'BE'],
      },
      billing_address_collection: 'required',
      metadata: {
        cart_items: JSON.stringify(items.map((item: any) => ({
          product_id: item.product.id,
          product_name: item.product.name,
          product_sku: item.product.sku || 'N/A',
          quantity: item.quantity,
          price: products?.find(p => p.id === item.product.id)?.price || item.product.price,
        }))),
        subtotal: subtotal.toString(),
        shipping_cost: shippingCost.toString(),
        user_id: user_id || '',
      },
      automatic_tax: {
        enabled: true,
      },
      expires_at: Math.floor(Date.now() / 1000) + (30 * 60), // 30 minutes
    });

    return new Response(
      JSON.stringify({ 
        sessionId: session.id, 
        url: session.url,
        expires_at: session.expires_at 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});