# ShopHub - Modern E-commerce Platform

A full-featured e-commerce platform built with React, TypeScript, Tailwind CSS, and Supabase. Features a beautiful storefront, comprehensive admin panel, and secure payment processing with Stripe.

![ShopHub Screenshot](https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800)

## ✨ Features

### Customer Features
- 🛍️ **Modern Shopping Experience** - Beautiful product catalog with advanced filtering
- 🔍 **Smart Search** - Search products by name, description, and tags
- 🛒 **Shopping Cart** - Persistent cart with quantity management
- 💳 **Secure Checkout** - Stripe integration for safe payments
- 👤 **User Accounts** - Registration, login, and profile management
- 📱 **Responsive Design** - Optimized for all devices
- ⭐ **Product Reviews** - Customer reviews and ratings
- 🏷️ **Categories & Brands** - Organized product browsing

### Admin Features
- 📊 **Dashboard** - Real-time analytics and insights
- 📦 **Product Management** - Full CRUD operations for products
- 🏪 **Category Management** - Organize products with categories and subcategories
- 🏷️ **Brand Management** - Manage product brands and manufacturers
- 👥 **User Management** - View and manage customer accounts
- 💰 **Transaction Management** - Monitor payments and orders
- ⚙️ **Settings** - Configure store settings and preferences

### Technical Features
- 🔐 **Row-Level Security** - Secure data access with Supabase RLS
- 🎨 **Modern UI/UX** - Clean design with Tailwind CSS
- 📱 **Mobile-First** - Responsive design for all screen sizes
- 🚀 **Fast Performance** - Optimized with Vite and React
- 🔒 **Type Safety** - Full TypeScript implementation
- 🌐 **SEO Friendly** - Optimized for search engines

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **Payments**: Stripe
- **Build Tool**: Vite
- **Icons**: Lucide React
- **Deployment**: Netlify

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- Supabase account
- Stripe account (for payments)

### 1. Clone the Repository

```bash
git clone <repository-url>
cd shophub
npm install
```

### 2. Environment Setup

Create a `.env` file in the root directory:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
```

### 3. Database Setup

1. **Create a Supabase project** at [supabase.com](https://supabase.com)
2. **Run the migrations** in your Supabase SQL editor:
   - Copy and run each migration file from `supabase/migrations/`
   - Start with the earliest migration and run them in order

3. **Set up Row-Level Security policies** (if not included in migrations):
   ```sql
   -- Enable RLS on all tables
   ALTER TABLE users ENABLE ROW LEVEL SECURITY;
   ALTER TABLE products ENABLE ROW LEVEL SECURITY;
   ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
   ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
   
   -- Add policies for authenticated users
   CREATE POLICY "Users can manage own data" ON users FOR ALL TO authenticated USING (auth.uid() = id);
   CREATE POLICY "Anyone can read active products" ON products FOR SELECT TO anon, authenticated USING (is_active = true);
   CREATE POLICY "Authenticated users can manage products" ON products FOR ALL TO authenticated USING (true);
   ```

### 4. Stripe Setup

1. **Create a Stripe account** at [stripe.com](https://stripe.com)
2. **Get your API keys** from the Stripe dashboard:
   - Publishable key (starts with `pk_`)
   - Secret key (starts with `sk_`)
3. **Add keys to your environment**:
   ```env
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key
   ```
   
   In your Supabase project settings, add these environment variables:
   ```
   STRIPE_SECRET_KEY=sk_test_your_secret_key
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
   ```

4. **Deploy Edge Functions**:
   ```bash
   # Deploy all Stripe-related functions
   supabase functions deploy create-checkout-session
   supabase functions deploy retrieve-checkout-session
   supabase functions deploy stripe-webhook
   ```

5. **Set up webhooks** in your Stripe dashboard:
   - Endpoint URL: `https://your-project-ref.supabase.co/functions/v1/stripe-webhook`
   - Events to send:
     - `checkout.session.completed`
     - `payment_intent.payment_failed`
     - `payment_intent.succeeded`
   - Copy the webhook signing secret to your Supabase environment variables

### 5. Run the Development Server

```bash
npm run dev
```

Visit `http://localhost:5173` to see the application.

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── admin/          # Admin panel components
│   ├── auth/           # Authentication components
│   └── checkout/       # Checkout flow components
├── hooks/              # Custom React hooks
├── lib/                # Utility libraries (Supabase, Stripe)
├── pages/              # Page components
├── types/              # TypeScript type definitions
└── data/               # Static data and mock data

supabase/
└── migrations/         # Database migration files
```

## 🔧 Common Issues & Solutions

### Database Issues

#### RLS Policy Violations
**Error**: `new row violates row-level security policy for table "products"`

**Solution**: Run the RLS policy migrations:
```sql
-- For products table
CREATE POLICY "Authenticated users can insert products" ON products FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update products" ON products FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete products" ON products FOR DELETE TO authenticated USING (true);

-- For brands table
CREATE POLICY "Authenticated users can insert brands" ON brands FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update brands" ON brands FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete brands" ON brands FOR DELETE TO authenticated USING (true);

-- For categories table
CREATE POLICY "Authenticated users can insert categories" ON categories FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update categories" ON categories FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Authenticated users can delete categories" ON categories FOR DELETE TO authenticated USING (true);
```

#### Missing Environment Variables
**Error**: `Missing Supabase environment variables`

**Solution**: 
1. Check your `.env` file exists and has the correct variables
2. Restart the development server after adding environment variables
3. Ensure variable names start with `VITE_` for Vite to include them

### Authentication Issues

#### Admin Access
**Error**: "Admin Access Required"

**Solution**: 
1. Create an admin user with email `admin@shophub.com`
2. Or modify the admin check in `src/pages/AdminPage.tsx`
3. For development, the current code allows any authenticated user to access admin

### Payment Issues

#### Stripe Integration
**Error**: Stripe checkout not working

**Solution**:
1. Verify your Stripe publishable key is correct
2. Check that Stripe is properly configured in your environment
3. Ensure you have the correct Stripe webhook endpoints set up

## 🚀 Deployment

### Deploy to Netlify

1. **Build the project**:
   ```bash
   npm run build
   ```

2. **Deploy using Netlify CLI**:
   ```bash
   npm install -g netlify-cli
   netlify deploy --prod --dir=dist
   ```

3. **Or use the Netlify dashboard**:
   - Connect your GitHub repository
   - Set build command: `npm run build`
   - Set publish directory: `dist`
   - Add environment variables in Netlify dashboard

### Environment Variables for Production

Add these to your Netlify environment variables:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_STRIPE_PUBLISHABLE_KEY`

## 🧪 Testing

```bash
# Run tests (when implemented)
npm run test

# Type checking
npm run type-check

# Linting
npm run lint
```

## 📝 API Documentation

### Supabase Tables

#### Products
- `id` - UUID primary key
- `name` - Product name
- `description` - Product description
- `price` - Product price
- `stock_quantity` - Available stock
- `category_id` - Foreign key to categories
- `brand_id` - Foreign key to brands
- `is_active` - Whether product is visible
- `is_featured` - Whether product is featured

#### Categories
- `id` - UUID primary key
- `name` - Category name
- `description` - Category description
- `parent_id` - Parent category (for subcategories)
- `is_active` - Whether category is visible

#### Brands
- `id` - UUID primary key
- `name` - Brand name
- `description` - Brand description
- `logo_url` - Brand logo URL
- `website_url` - Brand website
- `is_active` - Whether brand is visible

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

If you encounter any issues:

1. Check the [Common Issues](#-common-issues--solutions) section
2. Search existing GitHub issues
3. Create a new issue with detailed information
4. Join our community discussions

## 🙏 Acknowledgments

- [Supabase](https://supabase.com) for the backend infrastructure
- [Stripe](https://stripe.com) for payment processing
- [Tailwind CSS](https://tailwindcss.com) for the styling system
- [Lucide](https://lucide.dev) for the beautiful icons
- [Pexels](https://pexels.com) for the stock photos

---

Built with ❤️ using modern web technologies