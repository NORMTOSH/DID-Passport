import React, { useState } from 'react';
import { X, Heart, Share2, Star, Truck, Shield, RotateCcw, Plus, Minus, ShoppingCart, Eye, ChevronLeft, ChevronRight } from 'lucide-react';
import type { Product } from '../types';

interface ProductDetailProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState<'description' | 'specifications' | 'reviews'>('description');

  if (!isOpen || !product) return null;

  const images = product.images || [product.image];
  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleVariantChange = (variantName: string, value: string) => {
    setSelectedVariants(prev => ({
      ...prev,
      [variantName]: value
    }));
  };

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    // Show success feedback
    const button = document.getElementById('add-to-cart-btn');
    if (button) {
      button.textContent = 'Added!';
      setTimeout(() => {
        button.textContent = 'Add to Cart';
      }, 2000);
    }
  };

  const nextImage = () => {
    setSelectedImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setSelectedImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <div className="flex min-h-full items-center justify-center p-4">
          <div className="relative bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
                <div className="text-sm text-gray-500">
                  {product.category} / {product.brand}
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-red-500">
                  <Heart className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
              <div className="grid lg:grid-cols-2 gap-8 p-6">
                {/* Image Gallery */}
                <div className="space-y-4">
                  {/* Main Image */}
                  <div className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden group">
                    <img
                      src={images[selectedImageIndex]}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    
                    {/* Image Navigation */}
                    {images.length > 1 && (
                      <>
                        <button
                          onClick={prevImage}
                          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <button
                          onClick={nextImage}
                          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      </>
                    )}

                    {/* Badges */}
                    <div className="absolute top-4 left-4 flex flex-col space-y-2">
                      {product.featured && (
                        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                          Featured
                        </div>
                      )}
                      {discountPercentage > 0 && (
                        <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                          -{discountPercentage}%
                        </div>
                      )}
                    </div>

                    {/* Stock Status */}
                    <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-medium ${
                      product.inStock 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {product.inStock ? 'In Stock' : 'Sold Out'}
                    </div>
                  </div>

                  {/* Thumbnail Gallery */}
                  {images.length > 1 && (
                    <div className="flex space-x-2 overflow-x-auto pb-2">
                      {images.map((image, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedImageIndex(index)}
                          className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                            selectedImageIndex === index
                              ? 'border-blue-500'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <img
                            src={image}
                            alt={`${product.name} ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Product Info */}
                <div className="space-y-6">
                  {/* Title & Rating */}
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {product.name}
                    </h1>
                    {product.rating && (
                      <div className="flex items-center space-x-2 mb-4">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-5 h-5 ${
                                i < Math.floor(product.rating!)
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-lg font-medium text-gray-700">
                          {product.rating}
                        </span>
                        <span className="text-gray-500">
                          ({product.reviewCount} reviews)
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Price */}
                  <div className="flex items-center space-x-4">
                    <div className="text-4xl font-bold text-gray-900">
                      ${product.price}
                    </div>
                    {product.originalPrice && (
                      <div className="text-xl text-gray-500 line-through">
                        ${product.originalPrice}
                      </div>
                    )}
                    {discountPercentage > 0 && (
                      <div className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-semibold">
                        Save {discountPercentage}%
                      </div>
                    )}
                  </div>

                  {/* Stock Info */}
                  {product.stockCount && product.stockCount < 10 && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <div className="text-orange-700 font-medium text-sm">
                        ⚡ Only {product.stockCount} left in stock!
                      </div>
                    </div>
                  )}

                  {/* Variants */}
                  {product.variants && product.variants.length > 0 && (
                    <div className="space-y-4">
                      {Object.entries(
                        product.variants.reduce((acc, variant) => {
                          if (!acc[variant.name]) acc[variant.name] = [];
                          acc[variant.name].push(variant);
                          return acc;
                        }, {} as Record<string, typeof product.variants>)
                      ).map(([variantName, variants]) => (
                        <div key={variantName}>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            {variantName}
                          </label>
                          <div className="flex flex-wrap gap-2">
                            {variants.map((variant) => (
                              <button
                                key={variant.id}
                                onClick={() => handleVariantChange(variantName, variant.value)}
                                disabled={!variant.inStock}
                                className={`px-4 py-2 border rounded-lg text-sm font-medium transition-colors ${
                                  selectedVariants[variantName] === variant.value
                                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                                    : variant.inStock
                                    ? 'border-gray-300 hover:border-gray-400 text-gray-700'
                                    : 'border-gray-200 text-gray-400 cursor-not-allowed'
                                }`}
                              >
                                {variant.value}
                                {!variant.inStock && ' (Out of Stock)'}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Quantity & Add to Cart */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <label className="text-sm font-medium text-gray-700">
                        Quantity:
                      </label>
                      <div className="flex items-center border border-gray-300 rounded-lg">
                        <button
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          className="p-2 hover:bg-gray-100 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="px-4 py-2 font-medium min-w-[3rem] text-center">
                          {quantity}
                        </span>
                        <button
                          onClick={() => setQuantity(quantity + 1)}
                          className="p-2 hover:bg-gray-100 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <button
                      id="add-to-cart-btn"
                      onClick={handleAddToCart}
                      disabled={!product.inStock}
                      className={`w-full flex items-center justify-center space-x-2 px-6 py-4 rounded-xl font-semibold text-lg transition-all ${
                        product.inStock
                          ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transform hover:scale-105'
                          : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      <ShoppingCart className="w-5 h-5" />
                      <span>{product.inStock ? 'Add to Cart' : 'Sold Out'}</span>
                    </button>
                  </div>

                  {/* Trust Badges */}
                  <div className="grid grid-cols-3 gap-4 py-4 border-t border-gray-200">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Truck className="w-4 h-4 text-blue-600" />
                      <span>Free Shipping</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Shield className="w-4 h-4 text-green-600" />
                      <span>Secure Payment</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <RotateCcw className="w-4 h-4 text-purple-600" />
                      <span>Easy Returns</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Details Tabs */}
              <div className="border-t border-gray-200">
                <div className="max-w-4xl mx-auto p-6">
                  {/* Tab Navigation */}
                  <div className="flex space-x-8 border-b border-gray-200 mb-6">
                    <button
                      onClick={() => setActiveTab('description')}
                      className={`pb-4 text-sm font-medium transition-colors ${
                        activeTab === 'description'
                          ? 'text-blue-600 border-b-2 border-blue-600'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      Description
                    </button>
                    {product.specifications && (
                      <button
                        onClick={() => setActiveTab('specifications')}
                        className={`pb-4 text-sm font-medium transition-colors ${
                          activeTab === 'specifications'
                            ? 'text-blue-600 border-b-2 border-blue-600'
                            : 'text-gray-500 hover:text-gray-700'
                        }`}
                      >
                        Specifications
                      </button>
                    )}
                    <button
                      onClick={() => setActiveTab('reviews')}
                      className={`pb-4 text-sm font-medium transition-colors ${
                        activeTab === 'reviews'
                          ? 'text-blue-600 border-b-2 border-blue-600'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      Reviews ({product.reviewCount || 0})
                    </button>
                  </div>

                  {/* Tab Content */}
                  <div className="space-y-4">
                    {activeTab === 'description' && (
                      <div>
                        <p className="text-gray-700 leading-relaxed text-lg">
                          {product.description}
                        </p>
                        {product.tags.length > 0 && (
                          <div className="mt-6">
                            <h4 className="font-medium text-gray-900 mb-3">Tags</h4>
                            <div className="flex flex-wrap gap-2">
                              {product.tags.map((tag, index) => (
                                <span
                                  key={index}
                                  className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === 'specifications' && product.specifications && (
                      <div className="grid md:grid-cols-2 gap-4">
                        {Object.entries(product.specifications).map(([key, value]) => (
                          <div key={key} className="flex justify-between py-3 border-b border-gray-100">
                            <span className="font-medium text-gray-900">{key}</span>
                            <span className="text-gray-600">{value}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {activeTab === 'reviews' && (
                      <div className="space-y-6">
                        {product.rating && (
                          <div className="bg-gray-50 rounded-lg p-6">
                            <div className="flex items-center space-x-4 mb-4">
                              <div className="text-4xl font-bold text-gray-900">
                                {product.rating}
                              </div>
                              <div>
                                <div className="flex items-center mb-1">
                                  {[...Array(5)].map((_, i) => (
                                    <Star
                                      key={i}
                                      className={`w-5 h-5 ${
                                        i < Math.floor(product.rating!)
                                          ? 'fill-yellow-400 text-yellow-400'
                                          : 'text-gray-300'
                                      }`}
                                    />
                                  ))}
                                </div>
                                <div className="text-sm text-gray-600">
                                  Based on {product.reviewCount} reviews
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        
                        <div className="text-center py-8 text-gray-500">
                          <Eye className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <p>Reviews feature coming soon!</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};