import React from 'react';
import { CreditCard, Lock, Loader2 } from 'lucide-react';
import { useCheckout } from '../../hooks/useCheckout';
import type { CartItem } from '../../types';

interface CheckoutButtonProps {
  items: CartItem[];
  totalPrice: number;
  disabled?: boolean;
  className?: string;
}

export const CheckoutButton: React.FC<CheckoutButtonProps> = ({
  items,
  totalPrice,
  disabled = false,
  className = ''
}) => {
  const { createCheckoutSession, loading, error } = useCheckout();

  const handleCheckout = async () => {
    if (items.length === 0) return;

    try {
      // Transform cart items to the format expected by Stripe
      const stripeItems = items.map(item => ({
        product: {
          id: item.product.id,
          name: item.product.name,
          price: item.product.price,
          image: item.product.image,
          description: item.product.description || '',
          category: item.product.category,
          brand: item.product.brand
        },
        quantity: item.quantity
      }));
      
      await createCheckoutSession(stripeItems);
    } catch (err) {
      // Error is already handled in useCheckout hook
    }
  };

  const shippingCost = totalPrice >= 50 ? 0 : 9.99;
  const finalTotal = totalPrice + shippingCost;

  return (
    <div className="space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-red-700 text-sm">
            <strong>Checkout Error:</strong> {error}
          </p>
          <p className="text-red-600 text-xs mt-1">
            Please try again or contact support if the problem persists.
          </p>
        </div>
      )}

      <button
        onClick={handleCheckout}
        disabled={disabled || loading || items.length === 0}
        className={`w-full flex items-center justify-center space-x-2 px-6 py-4 rounded-xl font-semibold text-lg transition-all ${
          disabled || loading || items.length === 0
            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
            : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transform hover:scale-105'
        } ${className}`}
      >
        {loading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <CreditCard className="w-5 h-5" />
            <span>Secure Checkout - ${finalTotal.toFixed(2)}</span>
          </>
        )}
      </button>

      <div className="flex items-center justify-center space-x-2 text-xs text-gray-500">
        <Lock className="w-3 h-3" />
        <span>Secured by Stripe • SSL Encrypted</span>
      </div>

      <div className="text-center text-xs text-gray-500">
        <p>
          By proceeding, you agree to our{' '}
          <a href="#" className="text-blue-600 hover:underline">Terms of Service</a>
          {' '}and{' '}
          <a href="#" className="text-blue-600 hover:underline">Privacy Policy</a>
        </p>
      </div>
    </div>
  );
};