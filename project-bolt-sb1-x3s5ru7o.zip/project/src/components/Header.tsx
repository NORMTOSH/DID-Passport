import React, { useState, useRef, useEffect } from 'react';
import { ShoppingCart, Search, Menu, X, User, Heart, ChevronDown, Mail, Phone, Calendar, MapPin, Package, CreditCard, LogOut } from 'lucide-react';
import { useCategories } from '../hooks/useCategories';
import { useAuth } from '../hooks/useAuth';
import { useProfile } from '../hooks/useProfile';
import { useNavigate } from 'react-router-dom';

interface HeaderProps {
  cartItemsCount: number;
  onCartToggle: () => void;
  isLoggedIn: boolean;
  onAuthToggle: () => void;
  userName?: string;
}

export const Header: React.FC<HeaderProps> = ({
  cartItemsCount,
  onCartToggle,
  isLoggedIn,
  onAuthToggle,
  userName
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const { categories } = useCategories();
  const { user, signOut } = useAuth();
  const { profile } = useProfile();
  const dropdownRef = useRef<HTMLDivElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsCategoryDropdownOpen(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setIsUserDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleUserClick = () => {
    if (isLoggedIn) {
      setIsUserDropdownOpen(!isUserDropdownOpen);
    } else {
      // Show auth modal
      onAuthToggle();
    }
  };

  const handleSignOut = async () => {
    await signOut();
    setIsUserDropdownOpen(false);
    window.location.href = '/';
  };
  const handleCategoryClick = (categoryName: string) => {
    setIsCategoryDropdownOpen(false);
    setIsMobileMenuOpen(false);
    navigate(`/category/${encodeURIComponent(categoryName)}`);
  };

  const activeCategories = categories.filter(cat => cat.is_active);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <button
                onClick={() => navigate('/')}
                className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hover:from-blue-700 hover:to-purple-700 transition-all"
              >
                ShopHub
              </button>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Shop
            </a>
            
            {/* Categories Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsCategoryDropdownOpen(!isCategoryDropdownOpen)}
                className="flex items-center space-x-1 text-gray-700 hover:text-blue-600 transition-colors font-medium"
              >
                <span>Categories</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isCategoryDropdownOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isCategoryDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-50">
                  <div className="max-h-96 overflow-y-auto">
                    {activeCategories.length > 0 ? (
                      activeCategories.map((category) => (
                        <button
                          key={category.id}
                          onClick={() => handleCategoryClick(category.name)}
                          className="w-full flex items-center space-x-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                        >
                          {category.image_url && (
                            <img
                              src={category.image_url}
                              alt={category.name}
                              className="w-8 h-8 rounded-lg object-cover"
                            />
                          )}
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">{category.name}</p>
                            {category.description && (
                              <p className="text-xs text-gray-500 line-clamp-1">{category.description}</p>
                            )}
                          </div>
                        </button>
                      ))
                    ) : (
                      <div className="px-4 py-3 text-gray-500 text-sm">
                        No categories available
                      </div>
                    )}
                  </div>
                  
                  <div className="border-t border-gray-100 mt-2 pt-2">
                    <button
                      onClick={() => {
                        setIsCategoryDropdownOpen(false);
                        navigate('/categories');
                      }}
                      className="w-full px-4 py-2 text-left text-blue-600 hover:bg-blue-50 transition-colors font-medium text-sm"
                    >
                      View All Categories
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Deals
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              About
            </a>
            <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Support
            </a>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search products..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 hover:bg-white transition-colors"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            {/* Wishlist */}
            <button className="hidden md:flex p-2 text-gray-700 hover:text-red-500 transition-colors relative">
              <Heart className="w-5 h-5" />
            </button>

            {/* User Account */}
            <div className="relative" ref={userDropdownRef}>
              <button
                onClick={handleUserClick}
                className="hidden md:flex items-center space-x-2 px-3 py-2 rounded-full hover:bg-gray-100 transition-colors group"
              >
                <User className="w-4 h-4 text-gray-600 group-hover:text-blue-600 transition-colors" />
                <span className="text-sm font-medium text-gray-700 group-hover:text-blue-600 transition-colors">
                  {isLoggedIn && userName ? userName : 'Sign In'}
                </span>
                {isLoggedIn && (
                  <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform ${isUserDropdownOpen ? 'rotate-180' : ''}`} />
                )}
              </button>

              {/* User Profile Dropdown */}
              {isLoggedIn && isUserDropdownOpen && (
                <div className="absolute top-full right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 py-4 z-50">
                  {/* User Info Header */}
                  <div className="px-4 pb-4 border-b border-gray-100">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          {(profile?.first_name?.charAt(0) || '') + (profile?.last_name?.charAt(0) || '') || user?.email?.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">
                          {profile?.first_name || profile?.last_name 
                            ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim()
                            : 'User'
                          }
                        </h3>
                        <p className="text-sm text-gray-500">{user?.email}</p>
                      </div>
                    </div>
                  </div>

                  {/* User Details */}
                  <div className="px-4 py-3 space-y-2">
                    {profile?.phone && (
                      <div className="flex items-center space-x-3 text-sm">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-700">{profile.phone}</span>
                      </div>
                    )}
                    
                    {profile?.date_of_birth && (
                      <div className="flex items-center space-x-3 text-sm">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-700">
                          {new Date(profile.date_of_birth).toLocaleDateString()}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center space-x-3 text-sm">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-700">{user?.email}</span>
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <div className="px-4 py-3 border-t border-gray-100">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-gray-900">12</div>
                        <div className="text-xs text-gray-500">Orders</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-gray-900">$1,247</div>
                        <div className="text-xs text-gray-500">Spent</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-gray-900">156</div>
                        <div className="text-xs text-gray-500">Points</div>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="px-4 pt-3 border-t border-gray-100 space-y-2">
                    <button
                      onClick={() => {
                        setIsUserDropdownOpen(false);
                        navigate('/profile');
                      }}
                      className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-gray-50 rounded-lg transition-colors"
                    >
                      <User className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700 font-medium">View Profile</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        setIsUserDropdownOpen(false);
                        navigate('/orders');
                      }}
                      className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-gray-50 rounded-lg transition-colors"
                    >
                      <Package className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700 font-medium">My Orders</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        setIsUserDropdownOpen(false);
                        navigate('/admin');
                      }}
                      className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-gray-50 rounded-lg transition-colors"
                    >
                      <CreditCard className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700 font-medium">Admin Panel</span>
                    </button>
                    
                    <button
                      onClick={handleSignOut}
                      className="w-full flex items-center space-x-3 px-3 py-2 text-left hover:bg-red-50 rounded-lg transition-colors text-red-600"
                    >
                      <LogOut className="w-4 h-4" />
                      <span className="font-medium">Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
            {/* Cart Button */}
            <button
              onClick={onCartToggle}
              className="relative p-2 text-gray-700 hover:text-blue-600 transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium">
                  {cartItemsCount > 99 ? '99+' : cartItemsCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-gray-700 hover:text-blue-600 transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-200">
              {/* Mobile Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50"
                />
              </div>

              {/* Mobile Navigation */}
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Shop
              </a>
              
              {/* Mobile Categories */}
              <div className="px-3 py-2">
                <p className="text-sm font-medium text-gray-900 mb-2">Categories</p>
                <div className="space-y-1 ml-4">
                  {activeCategories.slice(0, 5).map((category) => (
                    <button
                      key={category.id}
                      onClick={() => handleCategoryClick(category.name)}
                      className="block text-gray-600 hover:text-blue-600 transition-colors text-sm"
                    >
                      {category.name}
                    </button>
                  ))}
                  {activeCategories.length > 5 && (
                    <button
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        navigate('/categories');
                      }}
                      className="block text-blue-600 hover:text-blue-700 transition-colors text-sm font-medium"
                    >
                      View All Categories
                    </button>
                  )}
                </div>
              </div>
              
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Deals
              </a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors font-medium">
                About
              </a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Support
              </a>

              {/* Mobile User Actions */}
              <div className="pt-4 border-t border-gray-200 space-y-2">
                <button
                  onClick={handleUserClick}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                >
                  <User className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    {isLoggedIn && userName ? userName : 'Sign In'}
                  </span>
                </button>
                
                <button className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
                  <Heart className="w-4 h-4" />
                  <span className="text-sm font-medium">Wishlist</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};