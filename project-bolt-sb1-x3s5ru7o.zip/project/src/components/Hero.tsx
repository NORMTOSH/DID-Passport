import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Truck, Shield, Award, Headphones } from 'lucide-react';

export const Hero: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white py-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent transform rotate-12 scale-150"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium">
                <Award className="w-4 h-4 mr-2" />
                Trusted by 1M+ customers worldwide
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                Shop Everything
                <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  {' '}You Love
                </span>
              </h1>
              <p className="text-xl text-blue-100 leading-relaxed">
                Discover amazing products from top brands with fast shipping, 
                secure checkout, and unbeatable prices. Your one-stop shop for everything.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => {
                  const productGrid = document.querySelector('#product-grid');
                  if (productGrid) {
                    productGrid.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 px-8 py-4 rounded-full font-semibold transition-all transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => navigate('/categories')}
                className="border-2 border-white/30 hover:border-white/50 px-8 py-4 rounded-full font-semibold transition-all backdrop-blur-sm hover:bg-white/10"
              >
                View Categories
              </button>
            </div>

            {/* Feature Icons */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-white/20 rounded-full">
                  <Truck className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Free Shipping</div>
                  <div className="text-xs text-blue-200">On orders $50+</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-white/20 rounded-full">
                  <Shield className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Secure Payment</div>
                  <div className="text-xs text-blue-200">100% Protected</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-white/20 rounded-full">
                  <Award className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Top Quality</div>
                  <div className="text-xs text-blue-200">Premium brands</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-white/20 rounded-full">
                  <Headphones className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <div className="font-semibold text-sm">24/7 Support</div>
                  <div className="text-xs text-blue-200">Always here</div>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Image/Animation */}
          <div className="relative">
            <div className="relative z-10">
              <img
                src="https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Shopping Experience"
                className="rounded-2xl shadow-2xl transform hover:scale-105 transition-transform duration-300"
              />
              
              {/* Floating Cards */}
              <div className="absolute -top-4 -left-4 bg-white/20 backdrop-blur-md rounded-xl p-4 animate-bounce">
                <div className="text-2xl font-bold">50%</div>
                <div className="text-sm opacity-80">Off Today</div>
              </div>
              
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 backdrop-blur-md rounded-xl p-4">
                <div className="text-2xl font-bold">10K+</div>
                <div className="text-sm opacity-80">Happy Customers</div>
              </div>
            </div>

            {/* Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-3xl blur-3xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};