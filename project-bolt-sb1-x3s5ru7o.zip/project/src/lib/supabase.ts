import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim();
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Environment variables:', {
    url: supabaseUrl,
    key: supabaseAnonKey ? 'Present' : 'Missing'
  });
  throw new Error(`Missing Supabase environment variables. URL: ${supabaseUrl ? 'Present' : 'Missing'}, Key: ${supabaseAnonKey ? 'Present' : 'Missing'}`);
}

console.log('Supabase URL:', supabaseUrl);

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  }
});

// Auth helpers
export const auth = {
  signUp: async (email: string, password: string, userData?: any) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: userData
      }
    });
    return { data, error };
  },

  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    return { data, error };
  },

  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  getCurrentUser: async () => {
    const { data: { user }, error } = await supabase.auth.getUser();
    return { user, error };
  },

  onAuthStateChange: (callback: (event: string, session: any) => void) => {
    return supabase.auth.onAuthStateChange(callback);
  }
};

// Database helpers
export const db = {
  // Products
  getProducts: async (filters?: {
    category?: string;
    brand?: string;
    minPrice?: number;
    maxPrice?: number;
    featured?: boolean;
    limit?: number;
    offset?: number;
  }) => {
    let query = supabase
      .from('products')
      .select(`
        *,
        categories(name),
        brands(name),
        product_images(image_url, alt_text, is_primary, sort_order),
        product_variants(*)
      `)
      .eq('is_active', true);

    if (filters?.category) {
      query = query.eq('categories.name', filters.category);
    }
    if (filters?.brand) {
      query = query.eq('brands.name', filters.brand);
    }
    if (filters?.minPrice) {
      query = query.gte('price', filters.minPrice);
    }
    if (filters?.maxPrice) {
      query = query.lte('price', filters.maxPrice);
    }
    if (filters?.featured) {
      query = query.eq('is_featured', true);
    }
    if (filters?.limit) {
      query = query.limit(filters.limit);
    }
    if (filters?.offset) {
      query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1);
    }

    return await query.order('created_at', { ascending: false });
  },

  getProduct: async (id: string) => {
    return await supabase
      .from('products')
      .select(`
        *,
        categories(name),
        brands(name),
        product_images(image_url, alt_text, is_primary, sort_order),
        product_variants(*),
        product_reviews(
          id, rating, title, content, is_verified_purchase, helpful_count, created_at,
          users(first_name, last_name)
        )
      `)
      .eq('id', id)
      .eq('is_active', true)
      .single();
  },

  // Cart
  getCartItems: async (userId?: string, sessionId?: string) => {
    let query = supabase
      .from('cart_items')
      .select(`
        *,
        products(
          id, name, price, image, stock_quantity, is_active,
          product_images(image_url, is_primary)
        )
      `);

    if (userId) {
      query = query.eq('user_id', userId);
    } else if (sessionId) {
      query = query.eq('session_id', sessionId);
    }

    return await query.order('created_at', { ascending: false });
  },

  addToCart: async (item: {
    userId?: string;
    sessionId?: string;
    productId: string;
    quantity: number;
    variantSelections?: any;
    priceAtTime: number;
  }) => {
    return await supabase.from('cart_items').insert({
      user_id: item.userId,
      session_id: item.sessionId,
      product_id: item.productId,
      quantity: item.quantity,
      variant_selections: item.variantSelections || {},
      price_at_time: item.priceAtTime
    });
  },

  updateCartItem: async (id: string, updates: { quantity?: number; variant_selections?: any }) => {
    return await supabase
      .from('cart_items')
      .update(updates)
      .eq('id', id);
  },

  removeFromCart: async (id: string) => {
    return await supabase
      .from('cart_items')
      .delete()
      .eq('id', id);
  },

  // Orders
  createOrder: async (orderData: any) => {
    return await supabase.from('orders').insert(orderData).select().single();
  },

  getUserOrders: async (userId: string) => {
    return await supabase
      .from('orders')
      .select(`
        *,
        order_items(
          *,
          products(name, image)
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
  },

  // User profile
  getUserProfile: async (userId: string) => {
    return await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
  },

  updateUserProfile: async (userId: string, updates: any) => {
    return await supabase
      .from('users')
      .update(updates)
      .eq('id', userId);
  },

  // Addresses
  getUserAddresses: async (userId: string) => {
    return await supabase
      .from('addresses')
      .select('*')
      .eq('user_id', userId)
      .order('is_default', { ascending: false });
  },

  addAddress: async (addressData: any) => {
    return await supabase.from('addresses').insert(addressData);
  },

  updateAddress: async (id: string, updates: any) => {
    return await supabase
      .from('addresses')
      .update(updates)
      .eq('id', id);
  },

  deleteAddress: async (id: string) => {
    return await supabase
      .from('addresses')
      .delete()
      .eq('id', id);
  }
};