import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetail } from './components/ProductDetail';
import { Cart } from './components/Cart';
import { Footer } from './components/Footer';
import { AuthModal } from './components/auth/AuthModal';
import { CheckoutSuccessPage } from './pages/CheckoutSuccessPage';
import { CheckoutCancelPage } from './pages/CheckoutCancelPage';
import { AdminPage } from './pages/AdminPage';
import { ProfilePage } from './pages/ProfilePage';
import { CategoryPage } from './pages/CategoryPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useCart } from './hooks/useCart';
import { useAuth } from './hooks/useAuth';
import type { Product } from './types';

function App() {
  const cart = useCart();
  const { user, signOut } = useAuth();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductDetailOpen, setIsProductDetailOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'signup'>('signin');

  const handleAuthToggle = () => {
    if (user) {
      // User is logged in, sign them out
      signOut();
    } else {
      // User is not logged in, show auth modal
      setAuthModalMode('signin');
      setIsAuthModalOpen(true);
    }
  };

  const handleCheckout = () => {
    if (!user) {
      setAuthModalMode('signin');
      setIsAuthModalOpen(true);
      return;
    }
    
    // Checkout will be handled by the CheckoutButton component
    console.log('Checkout initiated with Stripe');
  };

  const handleViewDetails = (product: Product) => {
    setSelectedProduct(product);
    setIsProductDetailOpen(true);
  };

  const handleCloseProductDetail = () => {
    setIsProductDetailOpen(false);
    setSelectedProduct(null);
  };

  const handleAddToCartFromDetail = (product: Product, quantity: number = 1) => {
    cart.addItem(product, quantity);
  };

  const handleAuthSuccess = () => {
    setIsAuthModalOpen(false);
  };

  return (
    <Router>
      <Routes>
        <Route path="/checkout/success" element={<CheckoutSuccessPage />} />
        <Route path="/checkout/cancel" element={<CheckoutCancelPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/categories" element={<CategoriesPage />} />
        <Route path="/category/:categoryName" element={<CategoryPage />} />
        <Route path="/" element={
          <div className="min-h-screen bg-white">
            <Header
              cartItemsCount={cart.getTotalItems()}
              onCartToggle={cart.toggleCart}
              onAuthToggle={handleAuthToggle}
              isLoggedIn={!!user}
              userName={user ? `${user.user_metadata?.first_name || ''} ${user.user_metadata?.last_name || ''}`.trim() || user.email : undefined}
            />
            
            <main>
              <Hero />
              <div id="product-grid">
                <ProductGrid
                  onAddToCart={cart.addItem}
                  onViewDetails={handleViewDetails}
                />
              </div>
            </main>

            <Footer />

            <Cart
              isOpen={cart.isOpen}
              onClose={cart.closeCart}
              items={cart.items}
              loading={cart.loading}
              onUpdateQuantity={cart.updateQuantity}
              onRemoveItem={cart.removeItem}
              totalPrice={cart.getTotalPrice()}
              onCheckout={handleCheckout}
            />

            <ProductDetail
              product={selectedProduct}
              isOpen={isProductDetailOpen}
              onClose={handleCloseProductDetail}
              onAddToCart={handleAddToCartFromDetail}
            />

            <AuthModal
              isOpen={isAuthModalOpen}
              onClose={() => setIsAuthModalOpen(false)}
              initialMode={authModalMode}
              onSuccess={handleAuthSuccess}
            />

            {/* Quick Access Links - Only show for logged in users */}
            {user && (
              <div className="fixed bottom-4 right-4 z-40 flex flex-col space-y-3">
                <a
                  href="/profile"
                  className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all text-sm font-medium shadow-lg"
                >
                  Profile
                </a>
              </div>
            )}
          </div>
        } />
      </Routes>
    </Router>
  );
}

export default App;