import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useCategories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('categories')
        .select(`
          *,
          parent_category:parent_id(id, name)
        `)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;

      setCategories(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch categories');
    } finally {
      setLoading(false);
    }
  };

  const createCategory = async (categoryData: any) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .insert(categoryData)
        .select()
        .single();
      
      if (error) throw error;
      await fetchCategories(); // Refresh list
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to create category' };
    } finally {
      setLoading(false);
    }
  };

  const updateCategory = async (id: string, updates: any) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      await fetchCategories(); // Refresh list
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to update category' };
    } finally {
      setLoading(false);
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await fetchCategories(); // Refresh list
      return { error: null };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'Failed to delete category' };
    } finally {
      setLoading(false);
    }
  };

  const getCategoryById = async (id: string) => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select(`
          *,
          parent_category:parent_id(id, name)
        `)
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to fetch category' };
    }
  };

  const getCategoryByName = async (name: string) => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select(`
          *,
          parent_category:parent_id(id, name)
        `)
        .eq('name', name)
        .eq('is_active', true)
        .single();
      
      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to fetch category' };
    }
  };

  const getActiveCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return { data: data || [], error: null };
    } catch (err) {
      return { data: [], error: err instanceof Error ? err.message : 'Failed to fetch categories' };
    }
  };

  return {
    categories,
    loading,
    error,
    createCategory,
    updateCategory,
    deleteCategory,
    getCategoryById,
    getCategoryByName,
    getActiveCategories,
    refetch: fetchCategories
  };
};