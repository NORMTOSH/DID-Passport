import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useProducts = (filters?: {
  category?: string;
  categoryId?: string;
  brand?: string;
  minPrice?: number;
  maxPrice?: number;
  featured?: boolean;
  search?: string;
  limit?: number;
  offset?: number;
}) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    fetchProducts();
  }, [JSON.stringify(filters)]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('products')
        .select(`
          *,
          categories(id, name),
          brands(id, name),
          product_images(image_url, alt_text, is_primary, sort_order)
        `, { count: 'exact' })
        .eq('is_active', true);

      // Apply filters
      if (filters?.categoryId) {
        query = query.eq('category_id', filters.categoryId);
      } else if (filters?.category && filters.category !== 'All') {
        // First get the category ID by name
        const { data: categoryData } = await supabase
          .from('categories')
          .select('id')
          .eq('name', filters.category)
          .eq('is_active', true)
          .single();
        
        if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }
      
      if (filters?.brand) {
        // First get the brand ID by name
        const { data: brandData } = await supabase
          .from('brands')
          .select('id')
          .eq('name', filters.brand)
          .eq('is_active', true)
          .single();
        
        if (brandData) {
          query = query.eq('brand_id', brandData.id);
        }
      }
      
      if (filters?.minPrice !== undefined) {
        query = query.gte('price', filters.minPrice);
      }
      
      if (filters?.maxPrice !== undefined) {
        query = query.lte('price', filters.maxPrice);
      }
      
      if (filters?.featured) {
        query = query.eq('is_featured', true);
      }

      if (filters?.search) {
        query = query.or(`name.ilike.%${filters.search}%,description.ilike.%${filters.search}%,tags.cs.{${filters.search}}`);
      }

      if (filters?.limit) {
        query = query.limit(filters.limit);
      }

      if (filters?.offset) {
        query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1);
      }

      const { data, error, count } = await query.order('created_at', { ascending: false });
      
      if (error) throw error;

      // Transform data to match our Product interface
      const transformedProducts = (data || []).map(product => ({
        id: product.id,
        name: product.name,
        description: product.description || '',
        price: parseFloat(product.price),
        originalPrice: product.original_price ? parseFloat(product.original_price) : undefined,
        image: product.product_images?.find(img => img.is_primary)?.image_url || 
               product.product_images?.[0]?.image_url || 
               'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
        images: product.product_images?.sort((a, b) => a.sort_order - b.sort_order).map(img => img.image_url) || [],
        category: product.categories?.name || 'Uncategorized',
        brand: product.brands?.name,
        inStock: product.stock_quantity > 0,
        stockCount: product.stock_quantity,
        featured: product.is_featured,
        rating: 4.5, // Mock rating - you can add this to database later
        reviewCount: Math.floor(Math.random() * 500) + 10, // Mock review count
        tags: product.tags || [],
        specifications: product.specifications || {},
        variants: [] // Add variants support later if needed
      }));

      setProducts(transformedProducts);
      setTotalCount(count || 0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  return { 
    products, 
    loading, 
    error, 
    totalCount,
    refetch: fetchProducts 
  };
};

export const useBrands = () => {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchBrands();
  }, []);

  const fetchBrands = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .eq('is_active', true)
        .order('name', { ascending: true });
      
      if (error) throw error;
      setBrands(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch brands');
    } finally {
      setLoading(false);
    }
  };

  return { brands, loading, error, refetch: fetchBrands };
};

export const useCategoriesForProducts = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch categories');
    } finally {
      setLoading(false);
    }
  };

  return { categories, loading, error, refetch: fetchCategories };
};