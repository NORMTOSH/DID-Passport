import { useState, useEffect } from 'react';
import { db } from '../lib/supabase';

export const useProducts = (filters?: any) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const { data, error } = await db.getProducts(filters);
        if (error) throw error;
        setProducts(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch products');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [JSON.stringify(filters)]);

  return { products, loading, error, refetch: () => fetchProducts() };
};

export const useProduct = (id: string) => {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const { data, error } = await db.getProduct(id);
        if (error) throw error;
        setProduct(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch product');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  return { product, loading, error };
};

export const useCart = (userId?: string, sessionId?: string) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCart = async () => {
    try {
      setLoading(true);
      const { data, error } = await db.getCartItems(userId, sessionId);
      if (error) throw error;
      setCartItems(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch cart');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userId || sessionId) {
      fetchCart();
    }
  }, [userId, sessionId]);

  const addToCart = async (item: any) => {
    try {
      const { error } = await db.addToCart(item);
      if (error) throw error;
      await fetchCart(); // Refresh cart
      return { error: null };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'Failed to add to cart' };
    }
  };

  const updateCartItem = async (id: string, updates: any) => {
    try {
      const { error } = await db.updateCartItem(id, updates);
      if (error) throw error;
      await fetchCart(); // Refresh cart
      return { error: null };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'Failed to update cart item' };
    }
  };

  const removeFromCart = async (id: string) => {
    try {
      const { error } = await db.removeFromCart(id);
      if (error) throw error;
      await fetchCart(); // Refresh cart
      return { error: null };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'Failed to remove from cart' };
    }
  };

  return {
    cartItems,
    loading,
    error,
    addToCart,
    updateCartItem,
    removeFromCart,
    refetch: fetchCart
  };
};

export const useOrders = (userId: string) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!userId) return;
      
      try {
        setLoading(true);
        const { data, error } = await db.getUserOrders(userId);
        if (error) throw error;
        setOrders(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch orders');
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [userId]);

  return { orders, loading, error };
};