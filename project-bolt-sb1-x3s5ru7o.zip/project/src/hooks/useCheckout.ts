import { useState } from 'react';
import { stripe } from '../lib/stripe';
import { useAuth } from './useAuth';
import type { CartItem } from '../types';

export const useCheckout = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const createCheckoutSession = async (items: CartItem[]) => {
    setLoading(true);
    setError(null);

    try {
      const { sessionId, url } = await stripe.createCheckoutSession(
        items,
        user?.email,
        user?.id
      );

      if (url) {
        window.location.href = url;
      } else {
        throw new Error('No checkout URL received');
      }

      return { sessionId, url };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Checkout failed';
      setError(errorMessage);
      console.error('Checkout error:', err);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const retrieveSession = async (sessionId: string) => {
    setLoading(true);
    setError(null);

    try {
      const session = await stripe.retrieveSession(sessionId);
      return session;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to retrieve session';
      setError(errorMessage);
      console.error('Session retrieval error:', err);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return {
    createCheckoutSession,
    retrieveSession,
    loading,
    error
  };
};