import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useAdminStats = () => {
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    totalUsers: 0,
    totalProducts: 0,
    activeUsers: 0,
    newUsersThisMonth: 0,
    bannedUsers: 0,
    successfulTransactions: 0,
    failedTransactions: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAdminStats();
  }, []);

  const fetchAdminStats = async () => {
    try {
      setLoading(true);

      // Fetch orders for revenue and order count
      const { data: orders, error: ordersError } = await supabase
        .from('orders')
        .select('total_amount, payment_status, created_at');
      
      if (ordersError) throw ordersError;

      // Fetch users count
      const { count: totalUsers, error: usersError } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true });
      
      if (usersError) throw usersError;

      // Fetch products count
      const { count: totalProducts, error: productsError } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true });
      
      if (productsError) throw productsError;

      // Fetch payment transactions
      const { data: transactions, error: transactionsError } = await supabase
        .from('payment_transactions')
        .select('status, amount');
      
      if (transactionsError) throw transactionsError;

      // Calculate stats
      const totalRevenue = orders?.filter(o => o.payment_status === 'paid')
        .reduce((sum, order) => sum + parseFloat(order.total_amount), 0) || 0;
      
      const totalOrders = orders?.length || 0;
      
      const successfulTransactions = transactions?.filter(t => t.status === 'succeeded').length || 0;
      const failedTransactions = transactions?.filter(t => t.status === 'failed').length || 0;

      // For demo purposes, calculate some mock stats
      const activeUsers = Math.floor((totalUsers || 0) * 0.85);
      const newUsersThisMonth = Math.floor((totalUsers || 0) * 0.15);
      const bannedUsers = Math.floor((totalUsers || 0) * 0.02);

      setStats({
        totalRevenue,
        totalOrders,
        totalUsers: totalUsers || 0,
        totalProducts: totalProducts || 0,
        activeUsers,
        newUsersThisMonth,
        bannedUsers,
        successfulTransactions,
        failedTransactions
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch admin stats');
    } finally {
      setLoading(false);
    }
  };

  return { stats, loading, error, refetch: fetchAdminStats };
};

export const useAdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories(name),
          brands(name),
          product_images(image_url, is_primary)
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setProducts(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch products');
    } finally {
      setLoading(false);
    }
  };

  const createProduct = async (productData: any) => {
    try {
      const { data, error } = await supabase
        .from('products')
        .insert(productData)
        .select(`
          *,
          categories(name),
          brands(name),
          product_images(image_url, is_primary)
        `)
        .single();
      
      if (error) throw error;
      await fetchProducts(); // Refresh list
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to create product' };
    }
  };

  const updateProduct = async (id: string, updates: any) => {
    try {
      const { data, error } = await supabase
        .from('products')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select(`
          *,
          categories(name),
          brands(name),
          product_images(image_url, is_primary)
        `)
        .single();
      
      if (error) throw error;
      await fetchProducts(); // Refresh list
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err instanceof Error ? err.message : 'Failed to update product' };
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await fetchProducts(); // Refresh list
      return { error: null };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'Failed to delete product' };
    }
  };

  return {
    products,
    loading,
    error,
    createProduct,
    updateProduct,
    deleteProduct,
    refetch: fetchProducts
  };
};

export const useAdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Call the admin-users edge function
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, { headers });
      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      setUsers(result.data || []);
    } catch (err) {
      console.error('Error fetching users:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  const createUser = async (userData: any) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(userData)
      });

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      await fetchUsers(); // Refresh list
      return { data: result.data, error: null };
    } catch (err) {
      console.error('Error creating user:', err);
      console.error('Error creating user:', err);
      return { data: null, error: err instanceof Error ? err.message : 'Failed to create user' };
    }
  };

  const updateUser = async (id: string, updates: any) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users?id=${id}`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };
      
      const response = await fetch(apiUrl, {
        method: 'PUT',
        headers,
        body: JSON.stringify(updates)
      });

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      await fetchUsers(); // Refresh list
      return { data: result.data, error: null };
    } catch (err) {
      console.error('Error updating user:', err);
      return { data: null, error: err instanceof Error ? err.message : 'Failed to update user' };
    }
  };

  const deleteUser = async (id: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users?id=${id}`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, {
        method: 'DELETE',
        headers
      });

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      await fetchUsers(); // Refresh list
      return { error: null };
    } catch (err) {
      console.error('Error deleting user:', err);
      return { error: err instanceof Error ? err.message : 'Failed to delete user' };
    }
  };

  const banUser = async (id: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users?id=${id}`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ status: 'banned' })
      });

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      await fetchUsers(); // Refresh list
      return { data: result.data, error: null };
    } catch (err) {
      console.error('Error banning user:', err);
      return { data: null, error: err instanceof Error ? err.message : 'Failed to ban user' };
    }
  };

  const unbanUser = async (id: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users?id=${id}`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ status: 'active' })
      });

      const result = await response.json();

      if (result.error) {
        throw new Error(result.error);
      }

      await fetchUsers(); // Refresh list
      return { data: result.data, error: null };
    } catch (err) {
      console.error('Error unbanning user:', err);
      return { data: null, error: err instanceof Error ? err.message : 'Failed to unban user' };
    }
  };

  return {
    users,
    loading,
    error,
    createUser,
    updateUser,
    deleteUser,
    banUser,
    unbanUser,
    refetch: fetchUsers
  };
};

export const useAdminTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('payment_transactions')
        .select(`
          *,
          orders(order_number),
          users(first_name, last_name, email)
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;

      // Transform data for display
      const transformedTransactions = (data || []).map(transaction => ({
        ...transaction,
        customerName: transaction.users 
          ? `${transaction.users.first_name || ''} ${transaction.users.last_name || ''}`.trim() || 'Unknown'
          : 'Guest',
        customerEmail: transaction.users?.email || 'N/A',
        orderId: transaction.orders?.order_number || 'N/A'
      }));

      setTransactions(transformedTransactions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch transactions');
    } finally {
      setLoading(false);
    }
  };

  return { transactions, loading, error, refetch: fetchTransactions };
};