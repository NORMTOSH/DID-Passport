import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useBrands = () => {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchBrands();
  }, []);

  const fetchBrands = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setBrands(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch brands');
    } finally {
      setLoading(false);
    }
  };

  const createBrand = async (brandData: any) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('brands')
        .insert(brandData)
        .select()
        .single();
      
      if (error) throw error;
      await fetchBrands(); // Refresh list
      return { data, error: null };
    } catch (err) {
      const errorMessage = err?.message || (err instanceof Error ? err.message : 'Failed to create brand');
      return { data: null, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  const updateBrand = async (id: string, updates: any) => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('brands')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      await fetchBrands(); // Refresh list
      return { data, error: null };
    } catch (err) {
      const errorMessage = err?.message || (err instanceof Error ? err.message : 'Failed to update brand');
      return { data: null, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  const deleteBrand = async (id: string) => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('brands')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await fetchBrands(); // Refresh list
      return { error: null };
    } catch (err) {
      const errorMessage = err?.message || (err instanceof Error ? err.message : 'Failed to delete brand');
      return { error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  const getBrandById = async (id: string) => {
    try {
      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      const errorMessage = err?.message || (err instanceof Error ? err.message : 'Failed to fetch brand');
      return { data: null, error: errorMessage };
    }
  };

  const getActiveBrands = async () => {
    try {
      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .eq('is_active', true)
        .order('name', { ascending: true });
      
      if (error) throw error;
      return { data: data || [], error: null };
    } catch (err) {
      const errorMessage = err?.message || (err instanceof Error ? err.message : 'Failed to fetch brands');
      return { data: [], error: errorMessage };
    }
  };

  return {
    brands,
    loading,
    error,
    createBrand,
    updateBrand,
    deleteBrand,
    getBrandById,
    getActiveBrands,
    refetch: fetchBrands
  };
};