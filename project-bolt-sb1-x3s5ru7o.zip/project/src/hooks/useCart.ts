import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import type { CartItem, Product } from '../types';

export const useCart = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sessionId, setSessionId] = useState<string>('');

  // Generate or get session ID for anonymous users
  useEffect(() => {
    if (!user) {
      let storedSessionId = localStorage.getItem('cart_session_id');
      if (!storedSessionId) {
        storedSessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        localStorage.setItem('cart_session_id', storedSessionId);
      }
      setSessionId(storedSessionId);
    }
  }, [user]);

  // Load cart items when user or session changes
  useEffect(() => {
    if (user || sessionId) {
      loadCartItems();
    }
  }, [user, sessionId]);

  const loadCartItems = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('cart_items')
        .select(`
          *,
          products(
            id, name, price, stock_quantity, is_active,
            product_images(image_url, is_primary),
            categories(name),
            brands(name)
          )
        `)
        .order('created_at', { ascending: false });

      if (user) {
        query = query.eq('user_id', user.id);
      } else if (sessionId) {
        query = query.eq('session_id', sessionId).is('user_id', null);
      }

      const { data, error } = await query;
      
      if (error) throw error;

      // Transform database items to CartItem format
      const cartItems: CartItem[] = (data || []).map(item => ({
        product: {
          id: item.products.id,
          name: item.products.name,
          price: item.price_at_time, // Use price at time of adding to cart
          originalPrice: undefined,
          image: item.products.product_images?.find(img => img.is_primary)?.image_url || 
                 item.products.product_images?.[0]?.image_url || 
                 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
          category: item.products.categories?.name || 'Uncategorized',
          brand: item.products.brands?.name,
          inStock: item.products.stock_quantity > 0 && item.products.is_active,
          stockCount: item.products.stock_quantity,
          featured: false,
          tags: [],
          description: ''
        },
        quantity: item.quantity,
        selectedVariants: item.variant_selections || {}
      }));

      setItems(cartItems);
    } catch (err) {
      console.error('Failed to load cart items:', err);
    } finally {
      setLoading(false);
    }
  };

  const addItem = useCallback(async (product: Product, quantity: number = 1) => {
    try {
      setLoading(true);

      // Check if item already exists in cart
      let query = supabase
        .from('cart_items')
        .select('*')
        .eq('product_id', product.id);

      if (user) {
        query = query.eq('user_id', user.id);
      } else if (sessionId) {
        query = query.eq('session_id', sessionId).is('user_id', null);
      }

      const { data: existingItems, error: fetchError } = await query;
      
      if (fetchError) throw fetchError;

      if (existingItems && existingItems.length > 0) {
        // Update existing item quantity
        const existingItem = existingItems[0];
        const { error: updateError } = await supabase
          .from('cart_items')
          .update({ 
            quantity: existingItem.quantity + quantity,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingItem.id);
        
        if (updateError) throw updateError;
      } else {
        // Add new item to cart
        const { error: insertError } = await supabase
          .from('cart_items')
          .insert({
            user_id: user?.id || null,
            session_id: user ? null : sessionId,
            product_id: product.id,
            quantity,
            price_at_time: product.price,
            variant_selections: {}
          });
        
        if (insertError) throw insertError;
      }

      // Reload cart items
      await loadCartItems();
    } catch (err) {
      console.error('Failed to add item to cart:', err);
    } finally {
      setLoading(false);
    }
  }, [user, sessionId]);

  const removeItem = useCallback(async (productId: string) => {
    try {
      setLoading(true);

      let query = supabase
        .from('cart_items')
        .delete()
        .eq('product_id', productId);

      if (user) {
        query = query.eq('user_id', user.id);
      } else if (sessionId) {
        query = query.eq('session_id', sessionId).is('user_id', null);
      }

      const { error } = await query;
      
      if (error) throw error;

      // Reload cart items
      await loadCartItems();
    } catch (err) {
      console.error('Failed to remove item from cart:', err);
    } finally {
      setLoading(false);
    }
  }, [user, sessionId]);

  const updateQuantity = useCallback(async (productId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeItem(productId);
      return;
    }

    try {
      setLoading(true);

      let query = supabase
        .from('cart_items')
        .update({ 
          quantity,
          updated_at: new Date().toISOString()
        })
        .eq('product_id', productId);

      if (user) {
        query = query.eq('user_id', user.id);
      } else if (sessionId) {
        query = query.eq('session_id', sessionId).is('user_id', null);
      }

      const { error } = await query;
      
      if (error) throw error;

      // Reload cart items
      await loadCartItems();
    } catch (err) {
      console.error('Failed to update cart item quantity:', err);
    } finally {
      setLoading(false);
    }
  }, [user, sessionId, removeItem]);

  const clearCart = useCallback(async () => {
    try {
      setLoading(true);

      let query = supabase.from('cart_items').delete();

      if (user) {
        query = query.eq('user_id', user.id);
      } else if (sessionId) {
        query = query.eq('session_id', sessionId).is('user_id', null);
      }

      const { error } = await query;
      
      if (error) throw error;

      setItems([]);
    } catch (err) {
      console.error('Failed to clear cart:', err);
    } finally {
      setLoading(false);
    }
  }, [user, sessionId]);

  const mergeGuestCart = useCallback(async () => {
    // Merge guest cart with user cart when user logs in
    if (!user || !sessionId) return;

    try {
      setLoading(true);

      // Get guest cart items
      const { data: guestItems, error: guestError } = await supabase
        .from('cart_items')
        .select('*')
        .eq('session_id', sessionId)
        .is('user_id', null);

      if (guestError) throw guestError;

      if (guestItems && guestItems.length > 0) {
        // Update guest items to belong to the user
        const { error: updateError } = await supabase
          .from('cart_items')
          .update({ 
            user_id: user.id,
            session_id: null,
            updated_at: new Date().toISOString()
          })
          .eq('session_id', sessionId)
          .is('user_id', null);

        if (updateError) throw updateError;

        // Clear the session ID since items are now associated with user
        localStorage.removeItem('cart_session_id');
        setSessionId('');
      }

      // Reload cart items
      await loadCartItems();
    } catch (err) {
      console.error('Failed to merge guest cart:', err);
    } finally {
      setLoading(false);
    }
  }, [user, sessionId]);

  // Merge guest cart when user logs in
  useEffect(() => {
    if (user && sessionId) {
      mergeGuestCart();
    }
  }, [user, sessionId, mergeGuestCart]);

  const getTotalItems = useCallback(() => {
    return items.reduce((total, item) => total + item.quantity, 0);
  }, [items]);

  const getTotalPrice = useCallback(() => {
    return items.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  }, [items]);

  const toggleCart = useCallback(() => {
    setIsOpen(prev => !prev);
  }, []);

  const closeCart = useCallback(() => {
    setIsOpen(false);
  }, []);

  return {
    items,
    isOpen,
    loading,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    getTotalItems,
    getTotalPrice,
    toggleCart,
    closeCart,
    loadCartItems
  };
};