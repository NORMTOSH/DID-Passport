import React, { useState } from 'react';
import { AdminLayout } from '../components/admin/AdminLayout';
import { Dashboard } from '../components/admin/Dashboard';
import { ProductManagement } from '../components/admin/ProductManagement';
import { CategoryManagement } from '../components/admin/CategoryManagement';
import { BrandManagement } from '../components/admin/BrandManagement';
import { UserManagement } from '../components/admin/UserManagement';
import { TransactionManagement } from '../components/admin/TransactionManagement';
import { AdminSettings } from '../components/admin/AdminSettings';
import { useAuth } from '../hooks/useAuth';

export const AdminPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { user } = useAuth();

  // Check if user is admin - Updated to be more permissive for development
  const isAdmin = user?.email === 'admin@shophub.com' ||
                  //user?.user_metadata?.role === 'admin' ||  // development
                  user?.user_metadata?.role === 'admin'; //production
                  user?.email?.includes('admin') ||
                  // For development: allow any authenticated user to access admin
                  !!user;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
          <p className="text-gray-600 mb-6">Please sign in to access the admin panel.</p>
          <button
            onClick={() => window.location.href = '/'}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go to Homepage
          </button>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <h1 className="text-2xl font-bold text-red-900 mb-4">Admin Access Required</h1>
          <p className="text-gray-600 mb-6">
            You need admin privileges to access this panel. 
          </p>
          
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-blue-900 mb-2">How to get admin access:</h3>
            <ul className="text-sm text-blue-800 text-left space-y-1">
              <li>• Sign in with email: <code className="bg-blue-100 px-1 rounded">admin@shophub.com</code></li>
              <li>• Or contact your system administrator</li>
            </ul>
          </div>
          
          <div className="space-y-3">
            <button
              onClick={() => window.location.href = '/'}
              className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Go to Homepage
            </button>
            
            <p className="text-xs text-gray-500">
              Current user: {user.email}
            </p>
          </div>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'products':
        return <ProductManagement />;
      case 'categories':
        return <CategoryManagement />;
      case 'brands':
        return <BrandManagement />;
      case 'users':
        return <UserManagement />;
      case 'transactions':
        return <TransactionManagement />;
      case 'settings':
        return <AdminSettings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <AdminLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </AdminLayout>
  );
};