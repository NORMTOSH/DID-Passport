import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Grid, ArrowRight, Package, Loader2 } from 'lucide-react';
import { useCategories } from '../hooks/useCategories';

export const CategoriesPage: React.FC = () => {
  const navigate = useNavigate();
  const { categories, loading, error } = useCategories();
  const [searchTerm, setSearchTerm] = useState('');

  const activeCategories = categories.filter(cat => cat.is_active);
  const parentCategories = activeCategories.filter(cat => !cat.parent_id);
  const subcategories = activeCategories.filter(cat => cat.parent_id);

  const filteredParentCategories = parentCategories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (category.description && category.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getSubcategoriesForParent = (parentId: string) => {
    return subcategories.filter(sub => sub.parent_id === parentId);
  };

  const handleCategoryClick = (categoryName: string) => {
    navigate(`/category/${encodeURIComponent(categoryName)}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading categories...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Error Loading Categories</h1>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-full font-medium hover:from-blue-700 hover:to-purple-700 transition-all"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Shop by Category
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
              Discover our wide range of products organized by categories. Find exactly what you're looking for.
            </p>

            {/* Search Bar */}
            <div className="max-w-md mx-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search categories..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Grid className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">{parentCategories.length}</h3>
            <p className="text-gray-600">Main Categories</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Package className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">{subcategories.length}</h3>
            <p className="text-gray-600">Subcategories</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <ArrowRight className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              {categories.reduce((sum, cat) => sum + (cat.product_count || 0), 0)}
            </h3>
            <p className="text-gray-600">Total Products</p>
          </div>
        </div>

        {/* Categories Grid */}
        {filteredParentCategories.length === 0 ? (
          <div className="text-center py-16">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              No categories found
            </h3>
            <p className="text-gray-600">
              {searchTerm ? `No categories match "${searchTerm}"` : 'No categories available yet'}
            </p>
          </div>
        ) : (
          <div className="space-y-12">
            {filteredParentCategories.map((category) => {
              const categorySubcategories = getSubcategoriesForParent(category.id);
              
              return (
                <div key={category.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                  {/* Parent Category Header */}
                  <div 
                    className="relative h-48 bg-gradient-to-r from-blue-600 to-purple-600 cursor-pointer group"
                    onClick={() => handleCategoryClick(category.name)}
                  >
                    {category.image_url && (
                      <img
                        src={category.image_url}
                        alt={category.name}
                        className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
                      />
                    )}
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
                    <div className="relative h-full flex items-center justify-center text-center p-8">
                      <div>
                        <h2 className="text-3xl font-bold text-white mb-2">{category.name}</h2>
                        {category.description && (
                          <p className="text-blue-100 text-lg max-w-2xl">{category.description}</p>
                        )}
                        <div className="mt-4 flex items-center justify-center space-x-4 text-blue-100">
                          <span>{category.product_count || 0} products</span>
                          {categorySubcategories.length > 0 && (
                            <span>• {categorySubcategories.length} subcategories</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Subcategories */}
                  {categorySubcategories.length > 0 && (
                    <div className="p-8">
                      <h3 className="text-lg font-semibold text-gray-900 mb-6">
                        {category.name} Subcategories
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {categorySubcategories.map((subcategory) => (
                          <button
                            key={subcategory.id}
                            onClick={() => handleCategoryClick(subcategory.name)}
                            className="group bg-gray-50 hover:bg-blue-50 rounded-xl p-6 text-left transition-all hover:shadow-md border border-transparent hover:border-blue-200"
                          >
                            <div className="flex items-start space-x-4">
                              {subcategory.image_url ? (
                                <img
                                  src={subcategory.image_url}
                                  alt={subcategory.name}
                                  className="w-16 h-16 rounded-lg object-cover"
                                />
                              ) : (
                                <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                                  <Package className="w-8 h-8 text-gray-400" />
                                </div>
                              )}
                              <div className="flex-1">
                                <h4 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors mb-1">
                                  {subcategory.name}
                                </h4>
                                {subcategory.description && (
                                  <p className="text-gray-600 text-sm line-clamp-2 mb-2">
                                    {subcategory.description}
                                  </p>
                                )}
                                <div className="flex items-center justify-between">
                                  <span className="text-sm text-gray-500">
                                    {subcategory.product_count || 0} products
                                  </span>
                                  <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
                                </div>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};