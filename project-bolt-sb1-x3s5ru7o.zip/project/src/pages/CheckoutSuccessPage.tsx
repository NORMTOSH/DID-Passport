import React, { useEffect, useState } from 'react';
import { CheckCircle, Package, Truck, Mail, ArrowRight, Home } from 'lucide-react';
import { useCheckout } from '../hooks/useCheckout';

export const CheckoutSuccessPage: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { retrieveSession } = useCheckout();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');

    if (sessionId) {
      retrieveSession(sessionId)
        .then(setSession)
        .catch(console.error)
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [retrieveSession]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading order details...</p>
        </div>
      </div>
    );
  }

  const orderTotal = session?.amount_total ? (session.amount_total / 100).toFixed(2) : '0.00';
  const customerEmail = session?.customer_details?.email;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-16">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Order Confirmed!
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Thank you for your purchase! Your order has been successfully processed and you'll receive a confirmation email shortly.
          </p>
        </div>

        {/* Order Summary */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 mb-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Order Details</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Order Number:</span>
                  <span className="font-medium">{session?.id?.slice(-8).toUpperCase() || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Amount:</span>
                  <span className="font-bold text-lg">${orderTotal}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Payment Status:</span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Paid
                  </span>
                </div>
                {customerEmail && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Email:</span>
                    <span className="font-medium">{customerEmail}</span>
                  </div>
                )}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">What's Next?</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Confirmation Email</h3>
                    <p className="text-sm text-gray-600">You'll receive an email confirmation with your order details</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Package className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Order Processing</h3>
                    <p className="text-sm text-gray-600">We'll prepare your items for shipment within 1-2 business days</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Truck className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">Shipping Updates</h3>
                    <p className="text-sm text-gray-600">Track your package with the tracking number we'll send you</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Shipping Information */}
        {session?.shipping_details && (
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Shipping Address</h2>
            <div className="text-gray-700">
              <p className="font-medium">{session.shipping_details.name}</p>
              <p>{session.shipping_details.address.line1}</p>
              {session.shipping_details.address.line2 && (
                <p>{session.shipping_details.address.line2}</p>
              )}
              <p>
                {session.shipping_details.address.city}, {session.shipping_details.address.state} {session.shipping_details.address.postal_code}
              </p>
              <p>{session.shipping_details.address.country}</p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => window.location.href = '/'}
            className="inline-flex items-center justify-center space-x-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105"
          >
            <Home className="w-5 h-5" />
            <span>Continue Shopping</span>
          </button>

          <button
            onClick={() => window.location.href = '/orders'}
            className="inline-flex items-center justify-center space-x-2 px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:border-gray-400 hover:bg-gray-50 transition-all"
          >
            <Package className="w-5 h-5" />
            <span>View Orders</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Support */}
        <div className="text-center mt-12 p-6 bg-gray-50 rounded-xl">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Need Help?</h3>
          <p className="text-gray-600 mb-4">
            If you have any questions about your order, our customer support team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:support@shophub.com"
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              support@shophub.com
            </a>
            <span className="hidden sm:inline text-gray-400">•</span>
            <a
              href="tel:1-800-SHOPHUB"
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              1-800-SHOPHUB
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};