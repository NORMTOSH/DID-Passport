import React from 'react';
import { XCircle, ArrowLeft, ShoppingCart, RefreshCw } from 'lucide-react';

export const CheckoutCancelPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50">
      <div className="max-w-2xl mx-auto px-4 py-16">
        {/* Cancel Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-red-100 rounded-full mb-6">
            <XCircle className="w-10 h-10 text-red-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Checkout Cancelled
          </h1>
          <p className="text-xl text-gray-600 max-w-lg mx-auto">
            Your payment was cancelled and no charges were made to your account. Your cart items are still saved.
          </p>
        </div>

        {/* Information Card */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">What Happened?</h2>
          <div className="space-y-4 text-gray-700">
            <p>
              You cancelled the checkout process before completing your payment. This can happen if:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>You clicked the back button or closed the payment window</li>
              <li>You decided to review your cart items again</li>
              <li>You encountered an issue with payment information</li>
              <li>You changed your mind about the purchase</li>
            </ul>
            <p className="font-medium text-gray-900">
              Don't worry - your cart items are still saved and ready for checkout when you're ready!
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <button
            onClick={() => window.location.href = '/'}
            className="w-full flex items-center justify-center space-x-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105"
          >
            <ShoppingCart className="w-5 h-5" />
            <span>Return to Cart</span>
          </button>

          <button
            onClick={() => window.location.href = '/'}
            className="w-full flex items-center justify-center space-x-2 px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:border-gray-400 hover:bg-gray-50 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Continue Shopping</span>
          </button>
        </div>

        {/* Help Section */}
        <div className="text-center mt-12 p-6 bg-blue-50 rounded-xl">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Need Assistance?</h3>
          <p className="text-gray-600 mb-4">
            If you experienced technical difficulties during checkout, our support team can help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:support@shophub.com"
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              Contact Support
            </a>
            <span className="hidden sm:inline text-gray-400">•</span>
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center space-x-1 text-blue-600 hover:text-blue-700 font-medium"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Try Again</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};