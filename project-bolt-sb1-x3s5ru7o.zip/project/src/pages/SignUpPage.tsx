import React from 'react';
import { ArrowLeft, ShoppingBag, Star, Users, Shield, Award } from 'lucide-react';
import { SignUpForm } from '../components/auth/SignUpForm';
import { useNavigate } from 'react-router-dom';

export const SignUpPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSuccess = () => {
    // Redirect to dashboard or home page after successful signup
    navigate('/');
  };

  const handleSwitchToSignIn = () => {
    navigate('/signin');
  };

  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <button
          onClick={handleGoBack}
          className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to shopping</span>
        </button>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Left Side - Benefits */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                Join the{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  ShopHub
                </span>{' '}
                Community
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Create your account and unlock exclusive benefits, personalized recommendations, 
                and seamless shopping experiences.
              </p>
            </div>

            {/* Benefits Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <ShoppingBag className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Exclusive Deals</h3>
                <p className="text-gray-600 text-sm">
                  Access member-only discounts and early access to sales
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Star className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Personalized Experience</h3>
                <p className="text-gray-600 text-sm">
                  Get product recommendations tailored to your preferences
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Secure Shopping</h3>
                <p className="text-gray-600 text-sm">
                  Shop with confidence using our secure payment system
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <Award className="w-6 h-6 text-orange-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Loyalty Rewards</h3>
                <p className="text-gray-600 text-sm">
                  Earn points with every purchase and unlock rewards
                </p>
              </div>
            </div>

            {/* Social Proof */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
              <div className="flex items-center space-x-4 mb-4">
                <Users className="w-8 h-8" />
                <div>
                  <div className="text-2xl font-bold">1M+</div>
                  <div className="text-blue-100">Happy Customers</div>
                </div>
              </div>
              <p className="text-blue-100">
                "ShopHub has transformed my online shopping experience. The personalized 
                recommendations are spot-on, and the customer service is exceptional!"
              </p>
              <div className="mt-4 flex items-center space-x-2">
                <div className="flex space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="text-sm text-blue-100">- Sarah M., Verified Customer</span>
              </div>
            </div>
          </div>

          {/* Right Side - Sign Up Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <SignUpForm
              onSuccess={handleSuccess}
              onSwitchToSignIn={handleSwitchToSignIn}
            />
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <p className="text-gray-500 text-sm mb-6">Trusted by leading companies worldwide</p>
          <div className="flex items-center justify-center space-x-8 opacity-60">
            <div className="text-2xl font-bold text-gray-400">VISA</div>
            <div className="text-2xl font-bold text-gray-400">PayPal</div>
            <div className="text-2xl font-bold text-gray-400">Stripe</div>
            <div className="text-2xl font-bold text-gray-400">SSL</div>
          </div>
        </div>
      </div>
    </div>
  );
};