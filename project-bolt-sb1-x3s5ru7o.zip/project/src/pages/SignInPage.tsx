import React from 'react';
import { ArrowLeft, ShoppingBag, Clock, Heart, Package } from 'lucide-react';
import { SignInForm } from '../components/auth/SignInForm';
import { useNavigate } from 'react-router-dom';

export const SignInPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSuccess = () => {
    // Redirect to dashboard or home page after successful signin
    navigate('/');
  };

  const handleSwitchToSignUp = () => {
    navigate('/signup');
  };

  const handleGoBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <button
          onClick={handleGoBack}
          className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to shopping</span>
        </button>

        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          {/* Left Side - Welcome Back */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
                Welcome Back to{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  ShopHub
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Sign in to access your account, view your orders, and continue your 
                amazing shopping journey with us.
              </p>
            </div>

            {/* Quick Access Features */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Track Your Orders</h3>
                  <p className="text-gray-600 text-sm">View real-time updates on your purchases</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Heart className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Your Wishlist</h3>
                  <p className="text-gray-600 text-sm">Access your saved items and favorites</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Order History</h3>
                  <p className="text-gray-600 text-sm">Review and reorder your past purchases</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <ShoppingBag className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Saved Cart</h3>
                  <p className="text-gray-600 text-sm">Continue where you left off</p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
              <h3 className="text-lg font-semibold mb-4">Your Shopping Stats</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">24</div>
                  <div className="text-blue-100 text-sm">Orders</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">$1,247</div>
                  <div className="text-blue-100 text-sm">Saved</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">156</div>
                  <div className="text-blue-100 text-sm">Points</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Sign In Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <SignInForm
              onSuccess={handleSuccess}
              onSwitchToSignUp={handleSwitchToSignUp}
              onForgotPassword={() => {
                // TODO: Navigate to forgot password page
                console.log('Navigate to forgot password');
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};