import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Noise-Canceling Headphones',
    description: 'Premium over-ear headphones with active noise cancellation, 30-hour battery life, and studio-quality sound. Experience music like never before with crystal-clear audio and industry-leading noise cancellation technology.',
    price: 299.99,
    originalPrice: 399.99,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/205926/pexels-photo-205926.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Electronics',
    brand: 'AudioTech',
    inStock: true,
    stockCount: 15,
    featured: true,
    rating: 4.8,
    reviewCount: 1247,
    tags: ['wireless', 'noise-canceling', 'premium', 'audio'],
    specifications: {
      'Battery Life': '30 hours',
      'Connectivity': 'Bluetooth 5.0',
      'Weight': '250g',
      'Warranty': '2 years',
      'Driver Size': '40mm',
      'Frequency Response': '20Hz - 20kHz',
      'Impedance': '32 ohms'
    }
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    description: 'Advanced fitness tracker with heart rate monitoring, GPS, sleep tracking, and 7-day battery life. Track your workouts, monitor your health, and stay connected with smart notifications.',
    price: 249.99,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/393047/pexels-photo-393047.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Electronics',
    brand: 'FitTech',
    inStock: true,
    stockCount: 32,
    featured: true,
    rating: 4.6,
    reviewCount: 892,
    tags: ['fitness', 'smartwatch', 'health', 'gps'],
    specifications: {
      'Display': '1.4" AMOLED',
      'Battery': '7 days',
      'Water Resistance': '5ATM',
      'Sensors': 'Heart Rate, GPS, Accelerometer',
      'Compatibility': 'iOS & Android',
      'Storage': '4GB'
    }
  },
  {
    id: '3',
    name: 'Organic Cotton T-Shirt',
    description: 'Soft, comfortable, and sustainable t-shirt made from 100% organic cotton. Perfect for everyday wear with a relaxed fit and breathable fabric that gets softer with every wash.',
    price: 29.99,
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Fashion',
    brand: 'EcoWear',
    inStock: true,
    stockCount: 78,
    featured: false,
    rating: 4.4,
    reviewCount: 324,
    tags: ['organic', 'cotton', 'sustainable', 'casual'],
    variants: [
      { id: 'size-s', name: 'Size', value: 'Small', inStock: true },
      { id: 'size-m', name: 'Size', value: 'Medium', inStock: true },
      { id: 'size-l', name: 'Size', value: 'Large', inStock: true },
      { id: 'size-xl', name: 'Size', value: 'X-Large', inStock: false }
    ],
    specifications: {
      'Material': '100% Organic Cotton',
      'Fit': 'Regular',
      'Care': 'Machine wash cold',
      'Origin': 'Made in USA',
      'Certification': 'GOTS Certified'
    }
  },
  {
    id: '4',
    name: 'Modern Coffee Table',
    description: 'Sleek and minimalist coffee table with solid wood construction and metal legs. Perfect for modern living spaces with its clean lines and durable construction that will last for years.',
    price: 399.99,
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Home & Garden',
    brand: 'ModernLiving',
    inStock: true,
    stockCount: 8,
    featured: true,
    rating: 4.7,
    reviewCount: 156,
    tags: ['furniture', 'modern', 'wood', 'living room'],
    specifications: {
      'Material': 'Solid Oak Wood',
      'Dimensions': '120cm x 60cm x 45cm',
      'Weight': '25kg',
      'Assembly': 'Required',
      'Finish': 'Natural Oil',
      'Style': 'Modern Minimalist'
    }
  },
  {
    id: '5',
    name: 'Professional Camera Lens',
    description: '85mm f/1.4 portrait lens with exceptional image quality and beautiful bokeh. Perfect for professional photography with its sharp optics and smooth focus ring for precise control.',
    price: 1299.99,
    image: 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Electronics',
    brand: 'LensMaster',
    inStock: true,
    stockCount: 5,
    featured: false,
    rating: 4.9,
    reviewCount: 89,
    tags: ['photography', 'lens', 'professional', 'portrait'],
    specifications: {
      'Focal Length': '85mm',
      'Aperture': 'f/1.4',
      'Mount': 'Canon EF',
      'Weight': '950g',
      'Filter Size': '77mm',
      'Min Focus Distance': '0.85m',
      'Elements': '9 elements in 7 groups'
    }
  },
  {
    id: '6',
    name: 'Luxury Skincare Set',
    description: 'Complete skincare routine with cleanser, serum, moisturizer, and SPF. Formulated with natural ingredients and clinically proven to improve skin texture and radiance in just 4 weeks.',
    price: 149.99,
    originalPrice: 199.99,
    image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/3762879/pexels-photo-3762879.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Beauty',
    brand: 'GlowLux',
    inStock: true,
    stockCount: 23,
    featured: false,
    rating: 4.5,
    reviewCount: 412,
    tags: ['skincare', 'luxury', 'natural', 'anti-aging'],
    specifications: {
      'Skin Type': 'All skin types',
      'Key Ingredients': 'Hyaluronic Acid, Vitamin C',
      'Cruelty Free': 'Yes',
      'Paraben Free': 'Yes',
      'Set Includes': '4 products',
      'Size': 'Full size products'
    }
  },
  {
    id: '7',
    name: 'Gaming Mechanical Keyboard',
    description: 'RGB backlit mechanical keyboard with tactile switches, programmable keys, and premium build quality. Designed for gamers and professionals who demand precision and durability.',
    price: 159.99,
    image: 'https://images.pexels.com/photos/2115257/pexels-photo-2115257.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/2115257/pexels-photo-2115257.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1194713/pexels-photo-1194713.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Electronics',
    brand: 'GameTech',
    inStock: true,
    stockCount: 19,
    featured: true,
    rating: 4.6,
    reviewCount: 678,
    tags: ['gaming', 'mechanical', 'rgb', 'keyboard'],
    specifications: {
      'Switch Type': 'Cherry MX Blue',
      'Backlight': 'RGB',
      'Connection': 'USB-C',
      'Key Layout': 'Full Size',
      'Polling Rate': '1000Hz',
      'Key Rollover': 'N-Key'
    }
  },
  {
    id: '8',
    name: 'Yoga Mat Premium',
    description: 'Extra thick, non-slip yoga mat made from eco-friendly materials. Perfect for all types of yoga practice with superior grip and cushioning for maximum comfort during your sessions.',
    price: 79.99,
    image: 'https://images.pexels.com/photos/3822864/pexels-photo-3822864.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/3822864/pexels-photo-3822864.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=800'
    ],
    category: 'Sports',
    brand: 'ZenFit',
    inStock: true,
    stockCount: 41,
    featured: false,
    rating: 4.3,
    reviewCount: 267,
    tags: ['yoga', 'fitness', 'eco-friendly', 'non-slip'],
    specifications: {
      'Thickness': '6mm',
      'Material': 'Natural Rubber',
      'Size': '183cm x 61cm',
      'Weight': '2.5kg',
      'Texture': 'Non-slip surface',
      'Eco-Friendly': 'Yes'
    }
  }
];

export const categories = [
  'All',
  'Electronics',
  'Fashion',
  'Home & Garden',
  'Beauty',
  'Sports',
  'Books',
  'Toys'
];

export const brands = [
  'AudioTech',
  'FitTech',
  'EcoWear',
  'ModernLiving',
  'LensMaster',
  'GlowLux',
  'GameTech',
  'ZenFit'
];